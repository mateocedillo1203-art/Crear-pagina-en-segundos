---
name: "adaptar-pagina-producto-pais"
description: "Adapta una página de producto de Shopify de otro país (link) a Ecuador u otro país de pago contra entrega, entregando bloques Custom Liquid listos para pegar con el botón de Releasit o EasySell."
---

# Adaptar una página de producto a otro país (Custom Liquid)

El usuario pega el link de una página de producto (de su tienda en otro país o de una referencia) y pide "pásala a Ecuador" (o Colombia, Guatemala, etc.) con sus precios. El entregable son 2 o 3 bloques **Custom Liquid** de Shopify, como archivos `.txt` (copia del `.liquid`), listos para pegar en el editor del tema.

## 1. Antes de construir (preguntar solo lo que falte)

- **País** y **precios** de cada oferta (ej. 1 por $29.99, 2 por $44.99). Si dan una oferta con unidades gratis, confirmar cuántas unidades lleva cada pack ("2+1" no es lo mismo que "2").
- **Formulario de compra** de esa tienda:
  - Releasit → hook `<a href="/rsi-btn-hook"></a>`
  - EasySell → hook `<span id="es-form-hook"></span>`
  - Si no lo dicen: Ecuador suele ser Releasit; preguntar si hay duda.
- **Garantía** (días) y si hay **regalos** reales que se envían. Si la página original promete regalos (e-book, sérum, cabezal) y no está confirmado que se envían, quitarlos y avisar.
- Moneda: si es otra moneda, convertir con el tipo de cambio del día (buscarlo en la web) y redondear a precios coherentes (ej. COP terminados en .900, Q en números redondos).

## 2. Leer la página original

Abrir el link en el navegador y extraer:
- Todo el texto de `main` (leerlo por partes si es largo).
- Las imágenes por sección (`img`, `video`, fondos), con su URL de CDN (`cdn.shopify.com/s/files/1/XXXX/XXXX/XXXX/files/...`) y su tamaño.
- Capturas de cada sección para copiar el diseño (colores, tipografía, orden).
- Valores animados (porcentajes que empiezan en 0%): leerlos tras hacer scroll o de los atributos `data-*`.
- Revisar las imágenes: si tienen precios en otra moneda, textos de otro país o promesas que no aplican, no usarlas o rehacer esa parte en HTML.

## 3. Adaptación al país (ejemplo Ecuador)

- Pago contra entrega ("pagas al recibir"), envío gratis a todo el país, entrega en 24 a 72 h hábiles (o lo que diga el usuario).
- Quitar: suscripciones, "cancela cuando quieras", tarjeta/PayPal/Shop Pay, "Black Friday" u ofertas de fechas, correos de contacto ajenos, menciones a otros países ("+1,240 mexicanos" → "+1,240 clientes").
- Moneda y formato del país (Ecuador USD $29.99; Colombia $119.000; Guatemala Q 299).
- Tachados coherentes con la misma proporción que la original. Calcular bien los % de ahorro y el precio por unidad.

## 4. Honestidad (obligatorio)

- No inventar médicos, premios, certificaciones ni estudios. Si la original muestra un "doctor" o premio que no se puede verificar, quitarlo y avisar.
- Suavizar promesas médicas absolutas: "Restaura" → "Favorece", "Baja tu cortisol" → "Ayuda a equilibrar", "Bloquea el DHT" → "Ayuda a contrarrestar". Quitar "supera al minoxidil", "absolutamente seguro", "sin efectos secundarios".
- Mantener precauciones de suplementos y dispositivos (embarazo, medicamentos, no usar sobre heridas).
- No cambiar las palabras de reseñas ni citas de personas reales. No agregar "verificado" si la original no lo dice.
- Si las fotos muestran algo que el producto no trae (ej. hilos dorados), agregar en letra pequeña: "Los X que aparecen en las fotos y videos son solo una referencia visual… El producto no incluye X."
- Comparaciones con competidores: solo hechos verificables y sin nombres de marcas.

## 5. Estructura de bloques

- **Bloque 1 (con botón):** galería con flechas, puntos y miniaturas; rating; título; beneficios; ofertas; **hook del formulario justo debajo de las ofertas**; sellos (envío gratis, pago al recibir, garantía); desplegables (descripción, uso, ingredientes, garantía, envío y pago); barra fija abajo en el celular que hace scroll al botón.
- **Bloque 2 y 3:** el resto de secciones de la original, en el mismo orden (videos, antes/después, beneficios, ingredientes, comparación, pasos, estadísticas, garantía, FAQ, reseñas), con botones que hacen scroll al botón de compra (`window.xxGoBuy`).
- Viene seleccionada la oferta 1, salvo que el usuario diga otra.

## 6. Reglas técnicas (para que no se rompa en Shopify)

- Cada bloque **menos de 50.000 caracteres**.
- **Nunca** `{{`, `}}` ni `{%` en el código (Liquid lo rompe). Al final, sanear: reemplazar `}}` por `} }` y `{{` por `{ {` hasta que no quede ninguno.
- Un ID raíz único por bloque (ej. `#av1`, `#av2`) y todo el CSS bajo ese ID.
- Quitar el padding del tema: `[class*="-padding"]:has(#av1){padding-top:0!important;padding-bottom:0!important}`.
- Tema Dawn oculta `div:empty`: los elementos vacíos (capas, separadores) deben ser `<i>`/`<span>` con `display:block`, o llenarse por JS.
- `position:fixed` no funciona dentro de un elemento con `container-type`: poner barras fijas fuera del contenedor.
- Imágenes: usar el CDN con `?width=N` (o `&width=N` si ya tiene `?v=`), que entrega webp liviano. Foto principal `fetchpriority="high"` y `preload`; el resto `loading="lazy"`. Galería: cargar solo la foto 1 y 4-5 miniaturas al abrir; las demás al deslizar o 2.5 s después del `load`. Máximo 1080 px de ancho.
- Imágenes con `width`/`height` + `height:auto` en CSS (si no, se estiran).
- Videos: `preload="none"`, cargar y reproducir solo al verse (IntersectionObserver), muted + playsinline. No usar videos de más de ~15 MB.
- Fuentes de Google sin bloquear: `media="print" onload="this.media='all'"`.
- Contadores a medianoche: `e.setHours(24,0,0,0)`.

## 7. Probar antes de entregar

Con Playwright (vista 390 px de ancho), simulando `div:empty{display:none}` y un wrapper con padding:
- Sin errores de JS y sin scroll horizontal.
- La galería, las ofertas, los desplegables y los botones funcionan.
- Captura completa para revisar el diseño.

## 8. Entregar

- Archivos `.txt` con nombre claro: `producto-pais-bloque1-con-boton.txt`, `...-bloque2.txt`, `...-bloque3.txt`.
- Mensaje corto con:
  - Tabla de precios final.
  - Qué se adaptó y qué se quitó (y por qué).
  - Qué debe configurar el usuario: ofertas y precios en Releasit/EasySell iguales a la página; garantía; subir las imágenes a Archivos de su propia tienda (si se cargan desde otra tienda, pueden dejar de verse).